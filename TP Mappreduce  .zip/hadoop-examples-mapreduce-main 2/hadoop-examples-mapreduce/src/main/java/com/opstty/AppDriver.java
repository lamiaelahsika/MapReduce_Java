package com.opstty;

import com.opstty.job.WordCount;
import org.apache.hadoop.util.ProgramDriver;

public class AppDriver {
    public static void main(String argv[]) {
        int exitCode = -1;
        ProgramDriver programDriver = new ProgramDriver();

        try {
            programDriver.addClass("wordcount", WordCount.class,
                    "A map/reduce program that counts the words in the input files.");
            programDriver.addClass("districts", Districts.class,
                    "A map/reduce program that list the districts from the input file ");
            programDriver.addClass("species", Species.class,
                    "A map/reduce program that displays the list of different species trees  from the input file ");
            programDriver.addClass("number_of_trees", Number_of_trees.class,
                    "A map/reduce program that calculates the number of trees of each species from the input file ");
            programDriver.addClass("maximum_height", Maximum_height.class,
                    "A map/reduce program that finds the highest tree of each specimen in the input .csv file.");
            programDriver.addClass("sort_trees_height", Sort_trees_height.class,
                    "A map/reduce program that displays all trees in increasing height order ");
            programDriver.addClass("districtoldest", DistrictOldest.class,
                    "A map/reduce program that displays the district with the oldest tree");

            exitCode = programDriver.run(argv);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }

        System.exit(exitCode);
    }
}
