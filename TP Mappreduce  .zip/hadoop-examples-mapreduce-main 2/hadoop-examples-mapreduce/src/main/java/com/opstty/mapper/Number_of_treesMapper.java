package com.opstty.mapper;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.StringTokenizer;

public class Number_of_trees extends Mapper<Object, Text, Text, NullWritable>
{
    private final static IntWritable one = new IntWritable(1);

    public void map(Object key, Text value, Context context)
            throws IOException, InterruptedException
    {
        String line = value.toString();
        if(!line.contain("ESPECE"))
        {
            Text number_of_species =new Text(line.split(";")[3]);
            context.write(number_of_species, one);

        }
    }
}