package com.opstty.comparator;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class HeightKey implements WritableComparable<HeightKey> {
    public String geopoint;
    public float height;

    public HeightKey() {
    }

    public HeightKey(String geopoint, float height) {
        super();
        this.set(geo,height);
    }

    public void set(String geopoint,float height) {
        this.geopoint = (geopoint == null) ? "" : geopoint;
        this.height = height;
    }

    @Override
    public void write(DataOutput out) throws IOException {
        out.writeUTF(geopoint);
        out.writeFloat(height);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        geopoint = in.readUTF();
        height = in.readFloat();
    }

    // Check values between height then checks geoposition string
    @Override
    public int compareTo(HeightKey o) {
        int heightCmp = Float.compare(height, o.height);
        if (heightCmp != 0) {
            return heightCmp;
        } else {
            return geopoint.toLowerCase().compareTo(o.geopoint.toLowerCase());
        }
    }

}
