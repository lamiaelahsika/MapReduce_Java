package com.opstty.mapper;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.StringTokenizer;

public class Sort_trees_heightMapper extends Mapper<Object, Text, Text, IntWritable>
{

    private float height;
    private String line = "";
    private String geopoint;
    int head = 0;

    private HeightKey heightkey = new HeightKey();

    public void map(Object key, Text value, Context context)
            throws IOException, InterruptedException
    {
        StringTokenizer itr = new StringTokenizer(value.toString(), "\n");
        while (itr.hasMoreTokens())
        {
            if(head == 1)
            {
                line = itr.nextToken();
                geo = line.split(";")[0];
                if (!line.split(";")[6].isEmpty())
                {
                    height = Float.parseFloat(line.split(";")[6]);
                }
                heightkey.set(geopoint,height);
                context.write(heightkey,NullWritable.get());
            }
            else
                {
                itr.nextToken();
                head= 1;
                }
        }
    }
}
