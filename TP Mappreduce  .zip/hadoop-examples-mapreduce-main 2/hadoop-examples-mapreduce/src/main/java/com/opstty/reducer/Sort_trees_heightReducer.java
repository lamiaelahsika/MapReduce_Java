package com.opstty.reducer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.util.*;

import java.io.IOException;

public class Sort_trees_heightReducer extends Reducer<Text, IntWritable, Text, IntWritable>
{
    private Text outputKey;

    public void reduce(HeightKey heightkey1, Iterable<NullWritable> values,Context context)
            throws IOException, InterruptedException {
        outputKey = new Text (String.format("%s %.2f", heightkey1key.geopoint, heightkey1.height));
        context.write(outputKey,NullWritable.get());
    }
}



