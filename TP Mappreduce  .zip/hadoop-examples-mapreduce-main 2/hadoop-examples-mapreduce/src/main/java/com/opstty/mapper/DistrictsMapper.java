package com.opstty.mapper;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.StringTokenizer;

public class DistrictsMapper extends Mapper<Object, Text, Text, NullWritable> {

    public void map(Object key, Text value, Context context)
            throws IOException, InterruptedException {
        String line = value.toString();
        if(!line.contain("ARRONDISSEMENT")){
            Text districts =new Text(line.split(";")[1]);
            context.write(districts , NullWritable.get());

        }
    }
}